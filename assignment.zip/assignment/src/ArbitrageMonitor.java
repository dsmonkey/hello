import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Detects arbitrage situation when bid > ask for a currency pair
 */
public class ArbitrageMonitor {

    public static void main(String [ ] args) {
        try {
            FilePriceReader reader = new FilePriceReader("prices.csv");

            // Example of reading in the prices
            FilePriceReader.Price nextPrice;
            while ((nextPrice = reader.getNextPrice()) != null) System.out.println("Reading in next price > " + nextPrice);
        }
        catch (FileNotFoundException fne) {
            System.out.println("File prices.csv not found");
        }
        catch (IOException ioe) {
            System.out.println("Error reading file " + ioe.getMessage());
        }
    }
}
